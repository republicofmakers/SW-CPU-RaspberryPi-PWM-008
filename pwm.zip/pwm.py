# servo_ws2812_loop.py
# PIN32 -> SG90 servo (GPIO12 / PWM0)
# PIN33 -> WS2812 (GPIO13 / PWM1)
# Run with: sudo python3 servo_ws2812_loop.py

import time
import pigpio
from rpi_ws281x import PixelStrip, Color

# ---------- Config ----------
# Servo on GPIO12 (physical pin 32)
SERVO_GPIO = 12
SERVO_MIN_US = 500     # ~0 deg (adjust 500-600 if needed)
SERVO_MAX_US = 2500    # ~180 deg (adjust 2400-2500 if needed)
SERVO_STEP_DEG = 2     # degrees per step for "normal" speed
SERVO_STEP_DELAY = 0.02  # seconds between steps (~20ms)

# WS2812 on GPIO13 (physical pin 33), PWM channel 1
LED_COUNT = 1          # number of LEDs in your strip/ring
LED_PIN = 13           # GPIO13 (PWM1)
LED_FREQ_HZ = 800000
LED_DMA = 10
LED_BRIGHTNESS = 255
LED_INVERT = False
LED_CHANNEL = 1        # IMPORTANT: GPIO13 uses channel 1
# ----------------------------

def angle_to_us(angle):
    """Map 0-180° to SERVO_MIN_US..SERVO_MAX_US pulse width."""
    angle = max(0, min(180, angle))
    span = SERVO_MAX_US - SERVO_MIN_US
    return int(SERVO_MIN_US + (span * (angle / 180.0)))

def set_led_color(strip, r, g, b):
    c = Color(r, g, b)
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, c)
    strip.show()

def main():
    # Setup servo (pigpio)
    pi = pigpio.pi()
    if not pi.connected:
        raise RuntimeError("pigpio daemon not running. Start it with: sudo pigpiod")

    # Initialize servo output (pigpio handles pulses)
    pi.set_mode(SERVO_GPIO, pigpio.OUTPUT)

    # Setup NeoPixel strip on GPIO13 / channel 1
    strip = PixelStrip(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT,
                       LED_BRIGHTNESS, LED_CHANNEL)
    strip.begin()

    # LED color cycle (B, R, G) with 1 second delay each
    colors = [(0, 0, 255), (255, 0, 0), (0, 255, 0)]
    next_color_index = 0
    next_color_time = time.time()

    # Start with first color
    set_led_color(strip, *colors[next_color_index])

    try:
        angle = 0
        direction = +1  # +1 going up to 180, -1 coming down to 0

        while True:
            # --- Servo sweep ---
            angle += direction * SERVO_STEP_DEG
            if angle >= 180:
                angle = 180
                direction = -1
            elif angle <= 0:
                angle = 0
                direction = +1

            pi.set_servo_pulsewidth(SERVO_GPIO, angle_to_us(angle))
            time.sleep(SERVO_STEP_DELAY)

            # --- LED 1-second color change ---
            now = time.time()
            if now >= next_color_time:
                next_color_index = (next_color_index + 1) % len(colors)
                set_led_color(strip, *colors[next_color_index])
                next_color_time = now + 1.0

    except KeyboardInterrupt:
        pass
    finally:
        # Turn off servo signal and LEDs on exit
        pi.set_servo_pulsewidth(SERVO_GPIO, 0)  # 0 = servo off
        set_led_color(strip, 0, 0, 0)
        pi.stop()

if __name__ == "__main__":
    main()
